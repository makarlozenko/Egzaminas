var files_dup =
[
    [ "Egzaminas.cpp", "_egzaminas_8cpp.html", "_egzaminas_8cpp" ],
    [ "Egzaminas.h", "_egzaminas_8h.html", "_egzaminas_8h" ],
    [ "funkcijos.cpp", "funkcijos_8cpp.html", "funkcijos_8cpp" ]
];