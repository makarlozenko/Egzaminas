var searchData=
[
  ['tolygumas_0',['tolygumas',['../_egzaminas_8h.html#a1765e60bc47522a1274e413e8acd2af2',1,'tolygumas(const std::string &amp;str):&#160;funkcijos.cpp'],['../funkcijos_8cpp.html#a1765e60bc47522a1274e413e8acd2af2',1,'tolygumas(const std::string &amp;str):&#160;funkcijos.cpp']]]
];
