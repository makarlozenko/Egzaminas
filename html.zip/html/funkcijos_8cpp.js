var funkcijos_8cpp =
[
    [ "splitWords", "funkcijos_8cpp.html#a54dc7c1154c2590dcc8e4448249d1c5e", null ],
    [ "tolygumas", "funkcijos_8cpp.html#a1765e60bc47522a1274e413e8acd2af2", null ]
];